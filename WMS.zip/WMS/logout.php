<?php
session_start();
require_once __DIR__ . '/auth.php';
logout_user();
